import React from 'react';
import ReactDOM from 'react-dom';

// Create component
const App = () => {
	return <div>Hi React!</div>;
}

// Take this component and put it in the page (DOM)
ReactDOM.render(<App />, document.querySelector('.container'));